package com.example.reteyk_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
